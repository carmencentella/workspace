

class nombreClase():
    def __init__(self,parametro_opcional1, ··· ,parametro_opcionalN):
        # cualquier código de inicialización aquí 

    # Cualquier número de funciones que accedan a los datos
    # Cada una tiene la forma:

    def nombreFuncion1(self,parametro_opcional1, ··· ,parametro_opcionalN):
        # contenido de la función 
         

    # ··· más funciones
    

    def nombreFuncionN(self,parametro_opcional1, ··· ,parametro_opcionalN):
        # contenido de la función 
    
# Código principal

