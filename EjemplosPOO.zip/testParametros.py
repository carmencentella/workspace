
        
def muestraInformacion(self):
        print()
        print('Estado de la TV:', self.marca)
        print('      Ubicacion:', self.ubicacion)
        if self.encendida:

